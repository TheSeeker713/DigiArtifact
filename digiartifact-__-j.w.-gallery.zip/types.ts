
export enum AppView {
  LAUNCHER = 'launcher',
  GALLERY = 'gallery',
  UNITY = 'unity'
}

export interface Artwork {
  id: string;
  title: string;
  artist: string;
  description: string;
  price: number;
  sourceUrl: string;    // Human sketch
  evolutionUrl: string; // AI Enhanced
  livingArtUrl: string; // AI Video
}

export interface GalleryState {
  currentFloor: number;
  selectedArtwork: Artwork | null;
  isInventoryOpen: boolean;
}
