
import React, { useState } from 'react';
import { AppView } from './types';
import Launcher from './components/Launcher';
import GalleryExperience from './components/GalleryExperience';
import UnityGallery from './components/UnityGallery';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.LAUNCHER);

  const renderView = () => {
    switch (currentView) {
      case AppView.GALLERY:
        return <GalleryExperience onExit={() => setCurrentView(AppView.LAUNCHER)} />;
      case AppView.UNITY:
        return <UnityGallery onExit={() => setCurrentView(AppView.LAUNCHER)} />;
      case AppView.LAUNCHER:
      default:
        return (
          <Launcher 
            onLaunchNative={() => setCurrentView(AppView.GALLERY)} 
            onLaunchUnity={() => setCurrentView(AppView.UNITY)} 
          />
        );
    }
  };

  return (
    <div className="w-full h-screen bg-black overflow-hidden relative">
      {renderView()}
    </div>
  );
};

export default App;
