
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Curates a description for an artwork based on its theme.
 * This simulates the "AI Evolution" thinking process.
 */
export const curatArtDescription = async (title: string, theme: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Describe the artistic evolution of a piece titled "${title}" which focuses on the theme of ${theme}. 
      The description should highlight how a raw human sketch was transformed into a high-fidelity AI render and finally into a moving digital organism. 
      Keep it professional, avant-garde, and under 100 words.`,
      config: {
        temperature: 0.8,
        topP: 0.9,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Gemini Curation Error:", error);
    return null;
  }
};
