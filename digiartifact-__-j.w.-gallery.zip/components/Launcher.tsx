
import React from 'react';
import { Monitor, Smartphone, ExternalLink, Zap, Layers, ShieldCheck } from 'lucide-react';

interface LauncherProps {
  onLaunchNative: () => void;
  onLaunchUnity: () => void;
}

const Launcher: React.FC<LauncherProps> = ({ onLaunchNative, onLaunchUnity }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#050505] text-white p-6 relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-900/10 blur-[120px] rounded-full" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-teal-900/10 blur-[120px] rounded-full" />

      <div className="max-w-5xl w-full z-10">
        <header className="mb-12 flex flex-col md:flex-row items-center justify-between border-b border-zinc-800 pb-8 gap-6">
          <div className="flex items-center gap-6">
            <div className="w-16 h-16 bg-zinc-900 rounded-2xl flex items-center justify-center shadow-2xl border border-zinc-800 overflow-hidden logo-float">
              {/* Assuming the logo image provided is named logo.png */}
              <img src="logo.png" alt="DIGIARTIFACT" className="w-full h-full object-cover p-1" onError={(e) => {
                e.currentTarget.src = "https://placehold.co/100x100/0a0a0a/4f46e5?text=DA";
              }} />
            </div>
            <div>
              <h1 className="text-3xl font-black tracking-tighter uppercase italic">DIGIARTIFACT</h1>
              <p className="text-indigo-400 text-[10px] uppercase tracking-[0.5em] font-bold mt-1">Immersive Studio // J.W. Catalog</p>
            </div>
          </div>
          <div className="flex gap-6 text-zinc-500 text-[10px] font-bold uppercase tracking-widest">
            <span className="flex items-center gap-2 px-4 py-2 bg-zinc-900/50 rounded-full border border-zinc-800">
              <Monitor size={12} className="text-indigo-500" /> Desktop
            </span>
            <span className="flex items-center gap-2 px-4 py-2 bg-zinc-900/50 rounded-full border border-zinc-800">
              <Smartphone size={12} className="text-teal-500" /> Quest 3
            </span>
          </div>
        </header>

        <main>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* OPTION 1: NATIVE WEB ENGINE */}
            <button 
              onClick={onLaunchNative}
              className="group relative bg-zinc-900/30 border border-zinc-800 rounded-3xl overflow-hidden hover:border-zinc-600 transition-all text-left flex flex-col h-full hover:shadow-[0_0_40px_rgba(0,0,0,1)]"
            >
              <div className="aspect-[16/10] bg-zinc-800 relative overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1614850523296-d8c1af93d400?auto=format&fit=crop&q=80&w=1200" 
                  alt="Native Web Engine"
                  className="w-full h-full object-cover opacity-40 group-hover:scale-105 transition-transform duration-[2s]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/20 to-transparent" />
                <div className="absolute top-4 left-4 flex gap-2">
                  <span className="px-3 py-1 bg-zinc-800/80 backdrop-blur-md rounded-full text-[9px] font-bold uppercase tracking-widest border border-zinc-700">WebGL 2.0</span>
                  <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-[9px] font-bold uppercase tracking-widest border border-green-500/30">Native</span>
                </div>
                <div className="absolute bottom-6 left-6">
                  <Zap size={24} className="text-indigo-500 mb-2" />
                  <h2 className="text-2xl font-bold text-white tracking-tight">STANDARD ATRIUM</h2>
                </div>
              </div>
              <div className="p-8 pt-0 flex-1 flex flex-col justify-between">
                <div>
                  <p className="text-zinc-400 text-sm leading-relaxed mb-6 font-light">
                    Optimized for instant access and seamless browsing of the J.W. archive across all standard hardware.
                  </p>
                  <div className="flex flex-wrap gap-2 mb-8">
                     <span className="text-[9px] text-zinc-500 font-mono border border-zinc-800 px-2 py-1 rounded">R3F ENGINE</span>
                     <span className="text-[9px] text-zinc-500 font-mono border border-zinc-800 px-2 py-1 rounded">FAST_CACHE</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-white text-xs font-bold uppercase tracking-[0.2em] group-hover:text-indigo-400 transition-colors">
                  Enter Gallery <ExternalLink size={14} />
                </div>
              </div>
            </button>

            {/* OPTION 2: UNITY 6 ENGINE */}
            <button 
              onClick={onLaunchUnity}
              className="group relative bg-indigo-950/10 border border-indigo-500/10 rounded-3xl overflow-hidden hover:border-indigo-500/40 transition-all text-left flex flex-col h-full shadow-[0_0_50px_rgba(79,70,229,0.03)]"
            >
              <div className="aspect-[16/10] bg-indigo-900/40 relative overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?auto=format&fit=crop&q=80&w=1200" 
                  alt="Unity 6 Pro"
                  className="w-full h-full object-cover opacity-50 group-hover:scale-105 transition-transform duration-[2s]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-indigo-950 via-indigo-950/20 to-transparent" />
                <div className="absolute top-4 left-4 flex gap-2">
                  <span className="px-3 py-1 bg-indigo-600 rounded-full text-[9px] font-bold uppercase tracking-widest">Unity 6 LTS</span>
                  <span className="px-3 py-1 bg-indigo-400/20 text-indigo-300 rounded-full text-[9px] font-bold uppercase tracking-widest border border-indigo-500/30">HQ RENDER</span>
                </div>
                <div className="absolute bottom-6 left-6">
                  <Layers size={24} className="text-teal-400 mb-2" />
                  <h2 className="text-2xl font-black text-white tracking-tighter italic underline decoration-indigo-500 underline-offset-8">PRO EXHIBITION</h2>
                </div>
              </div>
              <div className="p-8 pt-0 flex-1 flex flex-col justify-between bg-gradient-to-b from-transparent to-indigo-950/20">
                <div>
                  <p className="text-indigo-200/60 text-sm leading-relaxed mb-6 font-light">
                    The definitive DIGIARTIFACT experience. Featuring the full architectural atrium with 8K texture mapping and real-time physics.
                  </p>
                  <div className="flex flex-wrap gap-2 mb-8">
                     <span className="text-[9px] text-indigo-400 font-mono border border-indigo-500/20 px-2 py-1 rounded">QUEST_VR_OPTIMIZED</span>
                     <span className="text-[9px] text-indigo-400 font-mono border border-indigo-500/20 px-2 py-1 rounded">HRTF_AUDIO</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-[0.2em] group-hover:translate-x-1 transition-all">
                  Initialize Pro Engine <ArrowRight size={14} className="ml-1" />
                </div>
              </div>
            </button>
          </div>
        </main>

        <footer className="mt-16 pt-8 border-t border-zinc-800/50 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
             <ShieldCheck size={14} className="text-zinc-600" />
             <p className="text-zinc-600 text-[10px] uppercase tracking-widest">Official Studio Platform &copy; 2024 DIGIARTIFACT LTD.</p>
          </div>
          <div className="flex gap-8">
            <a href="#" className="text-zinc-500 hover:text-white transition-colors text-[9px] uppercase tracking-[0.2em]">Curation Notes</a>
            <a href="#" className="text-zinc-500 hover:text-white transition-colors text-[9px] uppercase tracking-[0.2em]">Press Kit</a>
          </div>
        </footer>
      </div>
    </div>
  );
};

const ArrowRight = ({ size, className }: { size: number, className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="5" y1="12" x2="19" y2="12"></line>
    <polyline points="12 5 19 12 12 19"></polyline>
  </svg>
);

export default Launcher;
