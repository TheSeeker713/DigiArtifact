
import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text, Float, MeshWobbleMaterial } from '@react-three/drei';
import * as THREE from 'three';
import ArtStation from './ArtStation';
import { ARTWORKS } from '../constants';
import { Artwork } from '../types';

interface SceneProps {
  onSelectArtwork: (artwork: Artwork) => void;
  onFloorChange: (floor: number) => void;
  currentFloor: number;
}

const Scene: React.FC<SceneProps> = ({ onSelectArtwork, onFloorChange, currentFloor }) => {
  const waterRef = useRef<THREE.Mesh>(null);
  const waterfallRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const y = state.camera.position.y;
    let floor = 1;
    if (y > 15) floor = 4;
    else if (y > 10) floor = 3;
    else if (y > 5) floor = 2;
    
    if (floor !== currentFloor) {
      onFloorChange(floor);
    }

    if (waterRef.current) {
      waterRef.current.position.y = 0.05 + Math.sin(state.clock.elapsedTime * 0.5) * 0.01;
    }
    if (waterfallRef.current) {
      waterfallRef.current.scale.y = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.005;
    }
  });

  const fontUrl = "https://fonts.gstatic.com/s/syncopate/v12/pe0sMIuSrx9T-p_MUMFp2ALf.woff";

  return (
    <group>
      {/* --- ARCHITECTURE --- */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 5, 0]} receiveShadow>
        <ringGeometry args={[10, 25, 64]} />
        <meshStandardMaterial color="#1a1a1a" roughness={0.3} metalness={0.8} />
      </mesh>

      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 10, 0]} receiveShadow>
        <ringGeometry args={[12, 25, 64]} />
        <meshStandardMaterial color="#1a1a1a" roughness={0.3} metalness={0.8} />
      </mesh>

      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 15, 0]} receiveShadow>
        <planeGeometry args={[50, 50]} />
        <meshStandardMaterial color="#111" roughness={0.4} metalness={0.7} />
      </mesh>

      {[0, 1, 2, 3].map((i) => (
        <mesh key={i} position={[Math.cos(i * Math.PI / 2) * 12, 7.5, Math.sin(i * Math.PI / 2) * 12]}>
          <cylinderGeometry args={[0.2, 0.3, 15, 32]} />
          <meshStandardMaterial color="#333" metalness={0.9} roughness={0.1} />
        </mesh>
      ))}

      {/* --- WATER SYSTEM --- */}
      <mesh ref={waterRef} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.1, 0]}>
        <circleGeometry args={[8, 64]} />
        <MeshWobbleMaterial color="#0c4a6e" factor={0.2} speed={1} transparent opacity={0.6} metalness={1} />
      </mesh>

      <mesh ref={waterfallRef} position={[0, 7.5, -6]}>
        <boxGeometry args={[6, 15, 0.05]} />
        <MeshWobbleMaterial color="#0ea5e9" factor={0.6} speed={3} transparent opacity={0.2} />
      </mesh>

      {/* --- ART EXHIBITS --- */}
      {ARTWORKS.map((art, idx) => {
        const floorLevel = (idx % 3) + 1;
        const floorY = floorLevel * 5 - 5;
        const angle = (idx * Math.PI * 0.5) + (Math.PI / 4);
        const radius = 18;
        return (
          <ArtStation 
            key={art.id}
            artwork={art}
            position={[Math.cos(angle) * radius, floorY + 1.8, Math.sin(angle) * radius]}
            rotation={[0, -angle + Math.PI / 2, 0]}
            onInteract={() => onSelectArtwork(art)}
          />
        );
      })}

      {/* --- BRANDING --- */}
      <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
        <group position={[0, 20, 0]}>
          <mesh>
            <octahedronGeometry args={[2, 0]} />
            <meshStandardMaterial color="#0ea5e9" emissive="#0ea5e9" emissiveIntensity={1} wireframe />
          </mesh>
          <Text
            position={[0, -3.5, 0]}
            fontSize={0.6}
            color="white"
            font={fontUrl}
            maxWidth={10}
            textAlign="center"
          >
            DIGIARTIFACT // AETHER
          </Text>
        </group>
      </Float>

      <Text
        position={[0, 2.5, -14]}
        fontSize={1.2}
        color="#ffffff"
        font={fontUrl}
        fillOpacity={0.05}
        textAlign="center"
      >
        J.W. GALLERY BY DIGIARTIFACT
      </Text>
    </group>
  );
};

export default Scene;
