
import React, { useState } from 'react';
import { useTexture, Float, Text, Html } from '@react-three/drei';
import { Artwork } from '../types';

interface ArtStationProps {
  artwork: Artwork;
  position: [number, number, number];
  rotation: [number, number, number];
  onInteract: () => void;
}

const ArtStation: React.FC<ArtStationProps> = ({ artwork, position, rotation, onInteract }) => {
  const [hovered, setHovered] = useState(false);

  // Textures for Source and Evolution
  const sketchTex = useTexture(artwork.sourceUrl);
  const evoTex = useTexture(artwork.evolutionUrl);

  return (
    <group 
      position={position} 
      rotation={rotation}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
      onClick={onInteract}
    >
      {/* Background Frame */}
      <mesh position={[0, 0, -0.2]}>
        <boxGeometry args={[9, 4, 0.1]} />
        <meshStandardMaterial color="#0a0a0a" roughness={0.1} metalness={0.9} />
      </mesh>

      {/* 1. SOURCE (Sketch) */}
      <group position={[-3, 0, 0]}>
        <mesh>
          <planeGeometry args={[2.5, 3.5]} />
          <meshBasicMaterial map={sketchTex} />
        </mesh>
        {/* Fix: Text component in @react-three/drei uses fillOpacity instead of opacity */}
        <Text position={[0, -2, 0]} fontSize={0.15} color="white" fillOpacity={0.6}>
          01. SOURCE (Sketch)
        </Text>
      </group>

      {/* 2. EVOLUTION (AI Enhancement) */}
      <group position={[0, 0, 0]}>
        <mesh>
          <planeGeometry args={[2.5, 3.5]} />
          <meshBasicMaterial map={evoTex} />
        </mesh>
        <Text position={[0, -2, 0]} fontSize={0.15} color="#4f46e5">
          02. EVOLUTION (AI HD)
        </Text>
      </group>

      {/* 3. LIVING ART (Video/GIF) */}
      <group position={[3, 0, 0]}>
        {/* We use an Html component for the animated part to ensure smooth GIF playback without heavy textures */}
        <Html transform position={[0, 0, 0.01]} scale={0.5} distanceFactor={10}>
          <div className="w-[450px] h-[630px] overflow-hidden pointer-events-none select-none border-2 border-indigo-500/30">
            <img 
              src={artwork.livingArtUrl} 
              alt="Living Art" 
              className="w-full h-full object-cover"
            />
          </div>
        </Html>
        <Text position={[0, -2, 0]} fontSize={0.15} color="#818cf8">
          03. LIVING ART (Motion)
        </Text>
      </group>

      {/* Interaction Prompt */}
      {hovered && (
        <Float speed={5} rotationIntensity={0.5} floatIntensity={0.5}>
          <group position={[0, 2.5, 0.5]}>
            <Text
              fontSize={0.25}
              color="white"
              anchorX="center"
              anchorY="middle"
              outlineWidth={0.02}
              outlineColor="#4f46e5"
            >
              INSPECT PIECE
            </Text>
            <mesh position={[0, -0.4, 0]}>
              <boxGeometry args={[2, 0.05, 0.01]} />
              <meshBasicMaterial color="#4f46e5" />
            </mesh>
          </group>
        </Float>
      )}

      {/* Label Box */}
      <mesh position={[0, -2.8, 0]}>
        <boxGeometry args={[4, 0.8, 0.1]} />
        <meshStandardMaterial color="#111" />
        <Text
          position={[0, 0, 0.1]}
          fontSize={0.2}
          color="white"
          maxWidth={3.8}
          textAlign="center"
        >
          {artwork.title.toUpperCase()}
        </Text>
      </mesh>
    </group>
  );
};

export default ArtStation;
