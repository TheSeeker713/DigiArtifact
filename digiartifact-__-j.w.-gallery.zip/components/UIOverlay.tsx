
import React from 'react';
import { X, ShoppingCart, ArrowRight, Home, Info, Box } from 'lucide-react';
import { Artwork } from '../types';

interface UIOverlayProps {
  artwork: Artwork | null;
  onClose: () => void;
  currentFloor: number;
  onExit: () => void;
  onEnterVR: () => void;
}

const UIOverlay: React.FC<UIOverlayProps> = ({ artwork, onClose, currentFloor, onExit, onEnterVR }) => {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden font-sans">
      {/* Top Navigation */}
      <div className="absolute top-8 right-8 flex gap-4 pointer-events-auto">
        <button 
          onClick={onEnterVR}
          className="bg-zinc-100 hover:bg-white text-black px-6 py-2.5 rounded-xl flex items-center gap-2 text-[10px] font-black tracking-[0.2em] transition-all shadow-2xl group border border-white/20"
        >
          <Box size={14} className="group-hover:rotate-12 transition-transform" /> VIRTUAL_REALITY
        </button>
        <button 
          onClick={onExit}
          className="bg-black/60 hover:bg-black/80 text-white p-2.5 rounded-xl backdrop-blur-md transition-all border border-white/10"
        >
          <Home size={18} />
        </button>
      </div>

      {/* Bottom Bar / Commerce Portal */}
      <div className="absolute bottom-8 right-8 pointer-events-auto">
         <div className="bg-zinc-950/90 backdrop-blur-3xl border border-white/5 rounded-3xl p-5 w-80 flex flex-col gap-5 shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
            <div className="flex items-center justify-between">
              <img src="logo.png" className="w-8 h-8 opacity-50 grayscale hover:grayscale-0 transition-all cursor-help" alt="DA" onError={(e)=>e.currentTarget.style.display='none'} />
              <span className="text-indigo-400 font-black text-[9px] uppercase tracking-[0.3em]">LEVEL {currentFloor}</span>
            </div>
            <div className="space-y-1">
              <h4 className="text-white font-bold text-xs uppercase tracking-wider italic">DIGIARTIFACT Curation</h4>
              <p className="text-zinc-500 text-[10px] leading-relaxed">The J.W. Gift Shop is accessible via the Ground Floor. Physical delivery available worldwide.</p>
            </div>
            <button className="w-full bg-white/5 hover:bg-white/10 text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 border border-white/10">
              OPEN CATALOG <ArrowRight size={12} />
            </button>
         </div>
      </div>

      {/* Art Inspector Modal */}
      {artwork && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-xl flex items-center justify-center pointer-events-auto p-4 md:p-12 z-50">
          <div className="bg-[#0a0a0a] border border-white/5 rounded-[40px] w-full max-w-6xl overflow-hidden shadow-2xl flex flex-col md:flex-row animate-in fade-in zoom-in duration-500">
            {/* Visuals */}
            <div className="w-full md:w-3/5 bg-black p-10 flex flex-col gap-8">
               <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-4xl font-black text-white tracking-tighter uppercase italic">{artwork.title}</h2>
                    <p className="text-indigo-500 text-[10px] font-bold tracking-[0.4em] uppercase mt-2">DIGIARTIFACT SERIAL_#00{artwork.id}</p>
                  </div>
                  <button onClick={onClose} className="p-3 bg-white/5 hover:bg-white/10 rounded-full text-zinc-500 hover:text-white transition-all">
                    <X size={24} />
                  </button>
               </div>
               
               <div className="grid grid-cols-3 gap-6 flex-1">
                  <div className="space-y-3">
                    <div className="aspect-[3/4] bg-zinc-900 rounded-3xl overflow-hidden grayscale hover:grayscale-0 transition-all duration-700">
                      <img src={artwork.sourceUrl} className="w-full h-full object-cover" />
                    </div>
                    <span className="text-[8px] text-zinc-600 uppercase font-black tracking-[0.3em] block text-center italic">01_CONCEPT</span>
                  </div>
                  <div className="space-y-3">
                    <div className="aspect-[3/4] bg-zinc-900 rounded-3xl overflow-hidden border border-indigo-500/20">
                      <img src={artwork.evolutionUrl} className="w-full h-full object-cover" />
                    </div>
                    <span className="text-[8px] text-indigo-400 uppercase font-black tracking-[0.3em] block text-center italic">02_EVOLUTION</span>
                  </div>
                  <div className="space-y-3">
                    <div className="aspect-[3/4] bg-zinc-900 rounded-3xl overflow-hidden border border-teal-500/20">
                      <img src={artwork.livingArtUrl} className="w-full h-full object-cover" />
                    </div>
                    <span className="text-[8px] text-teal-400 uppercase font-black tracking-[0.3em] block text-center italic">03_ARTIFACT</span>
                  </div>
               </div>
            </div>

            {/* Content & Commerce */}
            <div className="w-full md:w-2/5 p-12 flex flex-col border-t md:border-t-0 md:border-l border-white/5 bg-[#0a0a0a]">
              <div className="flex-1 space-y-8">
                <div className="flex items-center gap-3 text-white text-[10px] font-black uppercase tracking-[0.3em]">
                  <div className="w-2 h-2 rounded-full bg-indigo-500" /> J.W. ORIGINAL
                </div>
                
                <p className="text-zinc-400 leading-relaxed text-sm font-light">
                  {artwork.description}
                </p>

                <div className="space-y-6">
                  <h5 className="text-white font-black text-[10px] uppercase tracking-[0.3em] border-b border-white/5 pb-4">COLLECTION OPTIONS</h5>
                  <div className="flex flex-col gap-4">
                    <button className="flex items-center justify-between p-5 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/5 hover:border-white/20 transition-all text-left group">
                      <div>
                        <div className="text-white text-xs font-bold uppercase tracking-wider">Physical Print</div>
                        <div className="text-zinc-600 text-[10px] mt-1 font-mono">24x36 Museum Linen</div>
                      </div>
                      <div className="text-white font-black text-sm">${artwork.price}</div>
                    </button>
                    <button className="flex items-center justify-between p-5 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/5 hover:border-white/20 transition-all text-left group">
                      <div>
                        <div className="text-white text-xs font-bold uppercase tracking-wider">Digital Artifact</div>
                        <div className="text-zinc-600 text-[10px] mt-1 font-mono">R2 Secure Asset Link</div>
                      </div>
                      <div className="text-teal-400 font-black text-sm">${(artwork.price * 0.4).toFixed(0)}</div>
                    </button>
                  </div>
                </div>
              </div>

              <div className="mt-12 pt-8 border-t border-white/5">
                <button className="w-full bg-white text-black font-black py-5 rounded-2xl flex items-center justify-center gap-3 shadow-2xl transition-all transform hover:bg-indigo-500 hover:text-white active:scale-[0.98] text-[10px] tracking-[0.3em]">
                  <ShoppingCart size={18} /> ACQUIRE PIECE
                </button>
                <p className="text-center text-[8px] text-zinc-700 mt-6 uppercase tracking-[0.4em] font-mono">SECURE TRANS_LOCK: DIGIARTIFACT_COMMERCE</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UIOverlay;
