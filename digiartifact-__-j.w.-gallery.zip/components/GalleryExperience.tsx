
import React, { Suspense, useState, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { PointerLockControls, Sky, Environment, Stars, ContactShadows, useProgress, Grid } from '@react-three/drei';
import { XR, createXRStore } from '@react-three/xr';
import Scene from './Scene';
import UIOverlay from './UIOverlay';
import { Artwork } from '../types';
import { Play } from 'lucide-react';

const store = createXRStore();

interface LoaderProps {
  onStarted: () => void;
  started: boolean;
}

function Loader({ onStarted, started }: LoaderProps) {
  const { progress, active } = useProgress();
  const [showButton, setShowButton] = useState(false);

  useEffect(() => {
    if (progress >= 100 && !active) {
      const timer = setTimeout(() => setShowButton(true), 400);
      return () => clearTimeout(timer);
    }
  }, [progress, active]);

  if (started) return null;

  return (
    <div className="absolute inset-0 z-[100] flex items-center justify-center bg-[#050505] text-white flex-col gap-6 p-6">
      <div className="flex flex-col items-center gap-2">
        <div className="w-20 h-20 mb-4 bg-zinc-900 rounded-xl border border-zinc-800 p-2 animate-pulse">
           <img src="logo.png" className="w-full h-full object-contain" alt="DIGIARTIFACT" onError={(e) => e.currentTarget.style.display='none'} />
        </div>
        <div className="text-2xl font-black tracking-[0.4em] text-white uppercase italic">
          DIGIARTIFACT
        </div>
        <div className="text-[9px] text-zinc-600 tracking-[0.6em] uppercase font-mono">CORE_ENGINE_SYNC</div>
      </div>

      <div className="w-80 h-[1px] bg-zinc-900 overflow-hidden relative">
        <div 
          className="h-full bg-indigo-500 transition-all duration-700 ease-out" 
          style={{ width: `${progress}%` }} 
        />
      </div>

      <div className="h-16 flex flex-col items-center justify-center">
        {showButton ? (
          <button 
            onClick={onStarted}
            className="group flex items-center gap-4 bg-white text-black px-12 py-4 rounded-full font-black text-[10px] tracking-[0.3em] hover:bg-indigo-600 hover:text-white transition-all transform hover:scale-105 active:scale-95"
          >
            START SESSION
          </button>
        ) : (
          <div className="text-[10px] text-zinc-500 font-mono tracking-widest uppercase">
            Resolving Assets: {Math.round(progress)}%
          </div>
        )}
      </div>

      <div className="absolute bottom-12 text-[8px] text-zinc-700 max-w-xs text-center leading-relaxed tracking-[0.3em] uppercase">
        Proprietary Content of DIGIARTIFACT LTD. <br/> Artist: J.W.
      </div>
    </div>
  );
}

interface GalleryExperienceProps {
  onExit: () => void;
}

const GalleryExperience: React.FC<GalleryExperienceProps> = ({ onExit }) => {
  const [selectedArtwork, setSelectedArtwork] = useState<Artwork | null>(null);
  const [currentFloor, setCurrentFloor] = useState(1);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedArtwork(null);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="w-full h-screen relative bg-black cursor-none overflow-hidden font-sans">
      <Loader started={started} onStarted={() => setStarted(true)} />

      <Canvas 
        shadows 
        camera={{ position: [0, 1.8, 8], fov: 60 }}
        gl={{ antialias: true, alpha: false }}
      >
        <XR store={store}>
          <ambientLight intensity={0.7} />
          <pointLight position={[10, 10, 10]} intensity={1.5} castShadow />
          <spotLight position={[-10, 20, 10]} angle={0.15} penumbra={1} intensity={2} castShadow />
          
          <Sky sunPosition={[100, 20, 100]} />
          <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
          
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
            <planeGeometry args={[100, 100]} />
            <meshStandardMaterial color="#080808" roughness={0.4} metalness={0.6} />
          </mesh>
          <Grid position={[0, 0, 0]} args={[50, 50]} sectionColor="#222" cellColor="#111" infiniteGrid />

          <Suspense fallback={null}>
            <Environment preset="city" />
            <Scene 
              onSelectArtwork={setSelectedArtwork} 
              onFloorChange={setCurrentFloor}
              currentFloor={currentFloor}
            />
            {started && <PointerLockControls />}
            <ContactShadows position={[0, 0, 0]} opacity={0.6} scale={40} blur={2} far={4} />
          </Suspense>
        </XR>
      </Canvas>

      {started && (
        <>
          <UIOverlay 
            artwork={selectedArtwork} 
            onClose={() => setSelectedArtwork(null)}
            currentFloor={currentFloor}
            onExit={onExit}
            onEnterVR={() => store.enterVR()}
          />
          
          <div className="absolute top-8 left-8 text-white/40 text-[8px] tracking-[0.3em] uppercase flex flex-col gap-1 pointer-events-none select-none z-10">
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
              DIGIARTIFACT // LIVE
            </div>
            <div>ZONE: F{currentFloor} // {currentFloor === 1 ? 'GROUND_ZERO' : currentFloor === 4 ? 'AETHER_SKY' : 'SECTOR_CORE'}</div>
          </div>
          
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/10 text-[8px] tracking-[0.4em] pointer-events-none select-none z-10 uppercase text-center w-full font-mono">
            INPUT_MAPPING: WASD / MOUSE / XR_CONTROLLER
          </div>
        </>
      )}
    </div>
  );
};

export default GalleryExperience;
