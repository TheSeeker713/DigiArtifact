
import React, { useState, useEffect, useRef } from 'react';
import { Home, RefreshCw, Smartphone, Maximize, Cpu } from 'lucide-react';

interface UnityGalleryProps {
  onExit: () => void;
}

const UnityGallery: React.FC<UnityGalleryProps> = ({ onExit }) => {
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);
  const unityContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 5;
      if (progress >= 100) {
        progress = 100;
        setIsLoaded(true);
        clearInterval(interval);
      }
      setLoadingProgress(progress);
    }, 120);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full h-screen bg-black flex flex-col items-center justify-center relative overflow-hidden font-sans">
      <div 
        ref={unityContainerRef}
        className={`w-full h-full bg-[#030303] transition-opacity duration-1000 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
      >
        {isLoaded && (
          <div className="w-full h-full flex flex-col items-center justify-center text-zinc-900 text-[10px] font-mono tracking-[0.5em] uppercase text-center p-12">
            <div className="max-w-md space-y-12 animate-pulse">
              <img src="logo.png" className="w-32 h-32 mx-auto grayscale opacity-20" alt="DA" onError={(e)=>e.currentTarget.style.display='none'} />
              <div className="space-y-6">
                <p className="text-zinc-600">[ DIGIARTIFACT_PRO_BUILD_ACTIVE ]</p>
                <p className="text-[8px] leading-relaxed opacity-30">
                  Initializing spatial anchors. Link status: Meta Quest 3 Stable. <br/>
                  Awaiting J.W. asset package deployment.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {!isLoaded && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#050505] z-50">
          <div className="w-full max-w-sm flex flex-col items-center gap-16">
            <div className="flex flex-col items-center gap-6">
               <div className="w-24 h-24 bg-zinc-900 flex items-center justify-center rounded-[32px] border border-white/5 relative group">
                 <div className="absolute inset-0 border-2 border-white/20 border-t-transparent animate-spin rounded-[32px]" />
                 <img src="logo.png" className="w-12 h-12 object-contain" alt="DA" />
               </div>
               <div className="text-center">
                 <h2 className="text-2xl font-black text-white tracking-[0.2em] uppercase italic">DIGIARTIFACT</h2>
                 <p className="text-zinc-600 text-[8px] tracking-[0.6em] uppercase mt-3">PRO_RENDER_PIPELINE // J.W.</p>
               </div>
            </div>

            <div className="w-full space-y-4">
              <div className="h-[2px] bg-zinc-900 rounded-full overflow-hidden w-full">
                <div 
                  className="h-full bg-white transition-all duration-300 shadow-[0_0_15px_white]" 
                  style={{ width: `${loadingProgress}%` }} 
                />
              </div>
              <div className="flex justify-between font-mono text-[8px] text-zinc-700 tracking-[0.5em]">
                <span>SYNC_NODES</span>
                <span>{Math.round(loadingProgress)}%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="absolute top-8 left-8 z-50 flex gap-4 pointer-events-auto">
        <button 
          onClick={onExit}
          className="bg-zinc-900/80 hover:bg-zinc-800 text-white p-4 rounded-2xl transition-all border border-white/5 group"
        >
          <Home size={20} className="group-hover:scale-110 transition-transform" />
        </button>
      </div>

      <div className="absolute bottom-8 right-8 z-50 pointer-events-none">
        <div className="bg-black/60 backdrop-blur-3xl border border-white/5 p-6 rounded-[32px] flex items-center gap-6">
           <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center">
             <img src="logo.png" className="w-8 h-8 object-contain p-1" alt="DA" />
           </div>
           <div>
              <div className="text-white text-[10px] font-black uppercase tracking-[0.4em] leading-none">DIGIARTIFACT</div>
              <div className="text-zinc-500 text-[8px] uppercase tracking-[0.5em] mt-2 font-mono italic">ENGINE_PRO_v4.2</div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default UnityGallery;
