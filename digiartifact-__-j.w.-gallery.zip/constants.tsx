
import { Artwork } from './types';

export const ARTWORKS: Artwork[] = [
  {
    id: '1',
    title: 'Cybernetic Genesis',
    artist: 'J.W.',
    description: 'The moment logic birthed soul within the machine. A study of emergent consciousness.',
    price: 450,
    sourceUrl: 'https://picsum.photos/seed/sketch1/800/1200',
    evolutionUrl: 'https://picsum.photos/seed/evo1/800/1200',
    livingArtUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM3Y4eG96eG96eG96eG96eG96eG96eG96eG96eG96eG96eG96JmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/3o7TKMGpxx8y9S3m6E/giphy.gif'
  },
  {
    id: '2',
    title: 'Fragmented Reality',
    artist: 'J.W.',
    description: 'A triptych exploring the breakdown of spatial dimensions in the digital age.',
    price: 600,
    sourceUrl: 'https://picsum.photos/seed/sketch2/800/1200',
    evolutionUrl: 'https://picsum.photos/seed/evo2/800/1200',
    livingArtUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM3Y4eG96eG96eG96eG96eG96eG96eG96eG96eG96eG96eG96JmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/l41lTf6fS8vK5K5Cg/giphy.gif'
  },
  {
    id: '3',
    title: 'Neural Cascade',
    artist: 'J.W.',
    description: 'Visualizing the weight of a thought as it traverses a synthetic synapse.',
    price: 320,
    sourceUrl: 'https://picsum.photos/seed/sketch3/800/1200',
    evolutionUrl: 'https://picsum.photos/seed/evo3/800/1200',
    livingArtUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM3Y4eG96eG96eG96eG96eG96eG96eG96eG96eG96eG96eG96JmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/3o7TKVUn7iM8FMEU24/giphy.gif'
  },
  {
    id: '4',
    title: 'Ethereal Blueprint',
    artist: 'J.W.',
    description: 'Architectural designs for a city that only exists in the collective subconscious.',
    price: 850,
    sourceUrl: 'https://picsum.photos/seed/sketch4/800/1200',
    evolutionUrl: 'https://picsum.photos/seed/evo4/800/1200',
    livingArtUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExM3Y4eG96eG96eG96eG96eG96eG96eG96eG96eG96eG96eG96JmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/3o7TKMGpxx8y9S3m6E/giphy.gif'
  }
];

export const FLOORS = [
  { level: 1, name: 'Lobby & Gift Shop', description: 'Grand entry with koi fountain' },
  { level: 2, name: 'The Source Atrium', description: 'Original sketches and core concepts' },
  { level: 3, name: 'Evolutionary Wing', description: 'High-fidelity AI enhancements' },
  { level: 4, name: 'Sky Lounge & Arcade', description: 'Rooftop pool and relaxation zone' }
];
